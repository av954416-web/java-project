import { Link, useLocation } from "wouter";
import { Car, Menu, Search, User, LogOut, Settings, LayoutDashboard, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/theme-toggle";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import type { User as UserType } from "@shared/schema";

// Mock user - will be replaced with actual auth
const mockUser: Partial<UserType> = {
  id: "1",
  name: "John Doe",
  email: "john@example.com",
  role: "renter",
  avatarUrl: null,
  verificationStatus: "approved",
};

export function Navbar() {
  const [location, setLocation] = useLocation();
  const isAuthenticated = true; // Replace with actual auth check

  const navLinks = [
    { href: "/browse", label: "Browse Cars" },
    { href: "/how-it-works", label: "How It Works" },
    { href: "/become-owner", label: "Become an Owner" },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2" data-testid="link-logo">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Car className="h-5 w-5" />
            </div>
            <span className="hidden font-display text-xl font-bold sm:inline-block">
              DriveHub
            </span>
          </Link>

          {/* Desktop Search */}
          <div className="hidden flex-1 max-w-md lg:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="search"
                placeholder="Search by location, car type..."
                className="w-full rounded-md border bg-background pl-10 pr-4 h-9 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                data-testid="input-search"
              />
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden items-center gap-6 lg:flex">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <Button
                  variant="ghost"
                  className={location === link.href ? "bg-accent" : ""}
                  data-testid={`link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  {link.label}
                </Button>
              </Link>
            ))}
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <>
                {mockUser.role === "owner" || mockUser.role === "renter" ? (
                  <Link href="/list-car">
                    <Button size="sm" className="hidden sm:flex" data-testid="button-list-car">
                      <Car className="mr-2 h-4 w-4" />
                      List Your Car
                    </Button>
                  </Link>
                ) : null}

                <ThemeToggle />

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="relative" data-testid="button-user-menu">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={mockUser.avatarUrl || undefined} />
                        <AvatarFallback>{mockUser.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      {mockUser.verificationStatus === "approved" && (
                        <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-chart-2 border-2 border-background" />
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>
                      <div className="flex flex-col">
                        <span className="font-semibold">{mockUser.name}</span>
                        <span className="text-xs text-muted-foreground">{mockUser.email}</span>
                        {mockUser.verificationStatus === "approved" && (
                          <Badge variant="secondary" className="mt-1 w-fit text-xs">
                            Verified
                          </Badge>
                        )}
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setLocation("/profile")} data-testid="menu-profile">
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/dashboard")} data-testid="menu-dashboard">
                      <LayoutDashboard className="mr-2 h-4 w-4" />
                      Dashboard
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/bookings")} data-testid="menu-bookings">
                      <Car className="mr-2 h-4 w-4" />
                      My Bookings
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/reviews")} data-testid="menu-reviews">
                      <Star className="mr-2 h-4 w-4" />
                      Reviews
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/settings")} data-testid="menu-settings">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive" data-testid="menu-logout">
                      <LogOut className="mr-2 h-4 w-4" />
                      Log Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <ThemeToggle />
                <Link href="/login">
                  <Button variant="ghost" size="sm" data-testid="button-login">
                    Log In
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="sm" data-testid="button-register">
                    Sign Up
                  </Button>
                </Link>
              </>
            )}

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px]">
                <div className="flex flex-col gap-4 mt-8">
                  {/* Mobile Search */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <input
                      type="search"
                      placeholder="Search cars..."
                      className="w-full rounded-md border bg-background pl-10 pr-4 h-9 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  {/* Mobile Navigation Links */}
                  {navLinks.map((link) => (
                    <Link key={link.href} href={link.href}>
                      <Button
                        variant="ghost"
                        className="w-full justify-start"
                        onClick={() => setLocation(link.href)}
                      >
                        {link.label}
                      </Button>
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
