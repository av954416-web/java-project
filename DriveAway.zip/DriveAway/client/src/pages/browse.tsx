import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Star, MapPin, CheckCircle2, Filter, SlidersHorizontal } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function Browse() {
  const [priceRange, setPriceRange] = useState([0, 500]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);

  const carTypes = ["Sedan", "SUV", "Truck", "Van", "Sports", "Luxury", "Electric"];
  const features = ["AC", "GPS", "Bluetooth", "Backup Camera", "Sunroof", "Leather Seats"];

  // Mock data - will be replaced with API
  const cars = [
    {
      id: "1",
      make: "Tesla",
      model: "Model 3",
      year: 2024,
      price: 89,
      location: "San Francisco, CA",
      rating: 4.9,
      reviews: 127,
      image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=800&h=500&fit=crop",
      features: ["Electric", "Autopilot", "Premium"],
      owner: { name: "Sarah M.", verified: true },
      type: "Electric"
    },
    {
      id: "2",
      make: "BMW",
      model: "X5",
      year: 2023,
      price: 125,
      location: "Los Angeles, CA",
      rating: 4.8,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&h=500&fit=crop",
      features: ["Luxury", "AWD", "Panoramic"],
      owner: { name: "Michael R.", verified: true },
      type: "SUV"
    },
    {
      id: "3",
      make: "Mercedes",
      model: "C-Class",
      year: 2024,
      price: 95,
      location: "San Diego, CA",
      rating: 5.0,
      reviews: 64,
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&h=500&fit=crop",
      features: ["Premium", "Navigation", "Leather"],
      owner: { name: "Emily J.", verified: true },
      type: "Sedan"
    },
    {
      id: "4",
      make: "Ford",
      model: "Mustang",
      year: 2023,
      price: 110,
      location: "Austin, TX",
      rating: 4.7,
      reviews: 95,
      image: "https://images.unsplash.com/photo-1584345604476-8ec5f5b7fbe5?w=800&h=500&fit=crop",
      features: ["Sports", "V8", "Manual"],
      owner: { name: "David L.", verified: true },
      type: "Sports"
    },
    {
      id: "5",
      make: "Toyota",
      model: "RAV4",
      year: 2024,
      price: 75,
      location: "Seattle, WA",
      rating: 4.9,
      reviews: 143,
      image: "https://images.unsplash.com/photo-1551830820-330a71b99659?w=800&h=500&fit=crop",
      features: ["Hybrid", "AWD", "Safety"],
      owner: { name: "Lisa K.", verified: true },
      type: "SUV"
    },
    {
      id: "6",
      make: "Audi",
      model: "A4",
      year: 2023,
      price: 105,
      location: "Denver, CO",
      rating: 4.8,
      reviews: 78,
      image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&h=500&fit=crop",
      features: ["Luxury", "Quattro", "Tech"],
      owner: { name: "James P.", verified: true },
      type: "Sedan"
    }
  ];

  const FilterPanel = () => (
    <div className="space-y-6">
      {/* Car Type */}
      <div>
        <h3 className="font-semibold mb-3">Car Type</h3>
        <div className="space-y-2">
          {carTypes.map((type) => (
            <div key={type} className="flex items-center gap-2">
              <Checkbox
                id={type}
                checked={selectedTypes.includes(type)}
                onCheckedChange={(checked) => {
                  if (checked) {
                    setSelectedTypes([...selectedTypes, type]);
                  } else {
                    setSelectedTypes(selectedTypes.filter((t) => t !== type));
                  }
                }}
                data-testid={`checkbox-type-${type.toLowerCase()}`}
              />
              <label htmlFor={type} className="text-sm cursor-pointer">
                {type}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <h3 className="font-semibold mb-3">Price per Day</h3>
        <Slider
          value={priceRange}
          onValueChange={setPriceRange}
          max={500}
          step={10}
          className="mb-2"
          data-testid="slider-price"
        />
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>${priceRange[0]}</span>
          <span>${priceRange[1]}</span>
        </div>
      </div>

      {/* Features */}
      <div>
        <h3 className="font-semibold mb-3">Features</h3>
        <div className="space-y-2">
          {features.map((feature) => (
            <div key={feature} className="flex items-center gap-2">
              <Checkbox id={feature} data-testid={`checkbox-feature-${feature.toLowerCase().replace(/\s+/g, "-")}`} />
              <label htmlFor={feature} className="text-sm cursor-pointer">
                {feature}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Transmission */}
      <div>
        <h3 className="font-semibold mb-3">Transmission</h3>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Checkbox id="automatic" data-testid="checkbox-automatic" />
            <label htmlFor="automatic" className="text-sm cursor-pointer">
              Automatic
            </label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox id="manual" data-testid="checkbox-manual" />
            <label htmlFor="manual" className="text-sm cursor-pointer">
              Manual
            </label>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-4xl font-bold mb-4">Browse Cars</h1>
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="search"
            placeholder="Search by location..."
            className="flex-1 rounded-md border bg-background px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            data-testid="input-location-search"
          />
          <Select defaultValue="relevance">
            <SelectTrigger className="w-full sm:w-[200px]" data-testid="select-sort">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="relevance">Most Relevant</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="newest">Newest First</SelectItem>
            </SelectContent>
          </Select>

          {/* Mobile Filter */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="lg:hidden" data-testid="button-mobile-filters">
                <SlidersHorizontal className="mr-2 h-4 w-4" />
                Filters
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px]">
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              <div className="mt-6">
                <FilterPanel />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <div className="flex gap-8">
        {/* Desktop Filters */}
        <aside className="hidden lg:block w-64 flex-shrink-0">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-semibold text-lg">Filters</h2>
              <Button variant="ghost" size="sm" data-testid="button-clear-filters">
                Clear
              </Button>
            </div>
            <FilterPanel />
          </Card>
        </aside>

        {/* Car Grid */}
        <div className="flex-1">
          <div className="mb-4">
            <p className="text-muted-foreground">
              Showing <span className="font-semibold text-foreground">{cars.length}</span> cars
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {cars.map((car) => (
              <Link key={car.id} href={`/cars/${car.id}`}>
                <Card className="overflow-hidden hover-elevate active-elevate-2 transition-all cursor-pointer h-full" data-testid={`card-car-${car.id}`}>
                  <div className="aspect-[16/10] relative overflow-hidden">
                    <img 
                      src={car.image} 
                      alt={`${car.make} ${car.model}`}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-3 right-3 bg-background/90 backdrop-blur-sm">
                      ${car.price}/day
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-lg">{car.make} {car.model}</h3>
                        <p className="text-sm text-muted-foreground">{car.year}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-chart-3 text-chart-3" />
                        <span className="text-sm font-medium">{car.rating}</span>
                        <span className="text-xs text-muted-foreground">({car.reviews})</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                      <MapPin className="h-4 w-4" />
                      {car.location}
                    </div>

                    <div className="flex flex-wrap gap-2 mb-3">
                      {car.features.slice(0, 3).map((feature, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 pt-3 border-t">
                      <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium">
                        {car.owner.name.charAt(0)}
                      </div>
                      <span className="text-sm">{car.owner.name}</span>
                      {car.owner.verified && (
                        <CheckCircle2 className="h-4 w-4 text-chart-2" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Load More */}
          <div className="mt-8 text-center">
            <Button variant="outline" size="lg" data-testid="button-load-more">
              Load More
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
