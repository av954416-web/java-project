import { useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Calendar } from "@/components/ui/calendar";
import { 
  Star, 
  MapPin, 
  CheckCircle2, 
  Users, 
  Gauge, 
  Fuel, 
  ChevronLeft,
  ChevronRight,
  Shield,
  Clock
} from "lucide-react";

export default function CarDetail() {
  const [, params] = useRoute("/cars/:id");
  const [, setLocation] = useLocation();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();

  // Mock data - will be replaced with API
  const car = {
    id: params?.id || "1",
    make: "Tesla",
    model: "Model 3",
    year: 2024,
    price: 89,
    location: "San Francisco, CA",
    rating: 4.9,
    reviews: 127,
    images: [
      "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=1200&h=800&fit=crop",
      "https://images.unsplash.com/photo-1571607388263-1044f9ea01dd?w=1200&h=800&fit=crop",
      "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=1200&h=800&fit=crop",
      "https://images.unsplash.com/photo-1536700503339-1e4b06520771?w=1200&h=800&fit=crop"
    ],
    features: ["Electric", "Autopilot", "Premium Interior", "Supercharger Access", "Full Self-Driving"],
    description: "Experience the future of driving with this stunning Tesla Model 3. Fully electric, zero emissions, and packed with cutting-edge technology. Perfect for city driving and long road trips alike.",
    specs: {
      seats: 5,
      transmission: "Automatic",
      fuel: "Electric",
      range: "358 miles"
    },
    owner: { 
      id: "owner1",
      name: "Sarah Mitchell", 
      verified: true,
      avatarUrl: null,
      memberSince: "2022",
      rating: 4.9,
      trips: 143,
      responseRate: "98%"
    }
  };

  const reviewsData = [
    {
      id: "1",
      reviewer: "Michael Chen",
      rating: 5,
      date: "2 weeks ago",
      comment: "Amazing car! Sarah was super responsive and the Tesla was in perfect condition. The autopilot feature made my road trip so much easier.",
      avatarUrl: null
    },
    {
      id: "2",
      reviewer: "Emily Rodriguez",
      rating: 5,
      date: "1 month ago",
      comment: "Best rental experience I've had. The car was clean, well-maintained, and the pickup/dropoff was seamless. Highly recommend!",
      avatarUrl: null
    },
    {
      id: "3",
      reviewer: "David Park",
      rating: 4,
      date: "2 months ago",
      comment: "Great car and good value. Only minor issue was finding a charging station in some areas, but overall fantastic experience.",
      avatarUrl: null
    }
  ];

  const calculateTotal = () => {
    if (!startDate || !endDate) return 0;
    const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    return days * car.price;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        onClick={() => setLocation("/browse")}
        className="mb-4"
        data-testid="button-back"
      >
        <ChevronLeft className="mr-2 h-4 w-4" />
        Back to Browse
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Images & Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Image Gallery */}
          <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
            <img 
              src={car.images[currentImageIndex]} 
              alt={`${car.make} ${car.model}`}
              className="w-full h-full object-cover"
            />
            {car.images.length > 1 && (
              <>
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute left-4 top-1/2 -translate-y-1/2"
                  onClick={() => setCurrentImageIndex((i) => (i === 0 ? car.images.length - 1 : i - 1))}
                  data-testid="button-prev-image"
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute right-4 top-1/2 -translate-y-1/2"
                  onClick={() => setCurrentImageIndex((i) => (i === car.images.length - 1 ? 0 : i + 1))}
                  data-testid="button-next-image"
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </>
            )}
          </div>

          {/* Thumbnail Gallery */}
          <div className="grid grid-cols-4 gap-2">
            {car.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentImageIndex(idx)}
                className={`aspect-video rounded-md overflow-hidden border-2 transition-all ${
                  currentImageIndex === idx ? "border-primary" : "border-transparent hover:border-muted-foreground/50"
                }`}
                data-testid={`thumbnail-${idx}`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>

          {/* Car Info */}
          <div>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="font-display text-4xl font-bold mb-2">
                  {car.make} {car.model}
                </h1>
                <p className="text-xl text-muted-foreground">{car.year}</p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold">${car.price}</div>
                <div className="text-sm text-muted-foreground">per day</div>
              </div>
            </div>

            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-1">
                <Star className="h-5 w-5 fill-chart-3 text-chart-3" />
                <span className="font-semibold">{car.rating}</span>
                <span className="text-muted-foreground">({car.reviews} reviews)</span>
              </div>
              <Separator orientation="vertical" className="h-4" />
              <div className="flex items-center gap-1 text-muted-foreground">
                <MapPin className="h-4 w-4" />
                {car.location}
              </div>
            </div>

            {/* Specs */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex items-center gap-3">
                    <Users className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Seats</div>
                      <div className="font-semibold">{car.specs.seats}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Gauge className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Transmission</div>
                      <div className="font-semibold">{car.specs.transmission}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Fuel className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Fuel Type</div>
                      <div className="font-semibold">{car.specs.fuel}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Shield className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Range</div>
                      <div className="font-semibold">{car.specs.range}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <div className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">Description</h2>
              <p className="text-muted-foreground leading-relaxed">{car.description}</p>
            </div>

            {/* Features */}
            <div className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">Features</h2>
              <div className="flex flex-wrap gap-2">
                {car.features.map((feature, idx) => (
                  <Badge key={idx} variant="secondary" className="text-sm">
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Owner Info */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={car.owner.avatarUrl || undefined} />
                    <AvatarFallback className="text-lg">{car.owner.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl font-semibold">{car.owner.name}</h3>
                      {car.owner.verified && (
                        <CheckCircle2 className="h-5 w-5 text-chart-2" />
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-4 mb-3">
                      <div>
                        <div className="text-sm text-muted-foreground">Member Since</div>
                        <div className="font-semibold">{car.owner.memberSince}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Total Trips</div>
                        <div className="font-semibold">{car.owner.trips}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Response Rate</div>
                        <div className="font-semibold">{car.owner.responseRate}</div>
                      </div>
                    </div>
                    <Link href={`/profile/${car.owner.id}`}>
                      <Button variant="outline" size="sm" data-testid="button-view-owner-profile">
                        View Profile
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reviews */}
            <div>
              <h2 className="text-2xl font-semibold mb-4">
                Reviews ({car.reviews})
              </h2>
              <div className="space-y-4">
                {reviewsData.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Avatar>
                          <AvatarImage src={review.avatarUrl || undefined} />
                          <AvatarFallback>{review.reviewer.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-semibold">{review.reviewer}</h4>
                            <div className="flex items-center gap-1">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating
                                      ? "fill-chart-3 text-chart-3"
                                      : "text-muted-foreground/30"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{review.date}</p>
                          <p className="text-sm">{review.comment}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Booking Card */}
        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-4">Book this car</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Start Date</label>
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    className="rounded-md border"
                    disabled={(date) => date < new Date()}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">End Date</label>
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    className="rounded-md border"
                    disabled={(date) => !startDate || date <= startDate}
                  />
                </div>

                {startDate && endDate && (
                  <div className="space-y-2 pt-4 border-t">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        ${car.price} × {Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))} days
                      </span>
                      <span className="font-semibold">${calculateTotal()}</span>
                    </div>
                    <div className="flex justify-between font-semibold text-lg pt-2 border-t">
                      <span>Total</span>
                      <span>${calculateTotal()}</span>
                    </div>
                  </div>
                )}

                <Button 
                  className="w-full" 
                  size="lg"
                  disabled={!startDate || !endDate}
                  onClick={() => setLocation("/booking")}
                  data-testid="button-book-now"
                >
                  Book Now
                </Button>

                <div className="flex items-start gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 mt-0.5" />
                  <span>Free cancellation up to 24 hours before pickup</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
