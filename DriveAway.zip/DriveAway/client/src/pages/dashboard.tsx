import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Car, 
  DollarSign, 
  TrendingUp, 
  Calendar,
  Check,
  X,
  Clock,
  Star,
  Plus
} from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  // Mock data
  const stats = {
    totalEarnings: 12450,
    thisMonth: 3280,
    totalBookings: 87,
    activeBookings: 3,
    carsListed: 2,
    avgRating: 4.9
  };

  const bookingRequests = [
    {
      id: "1",
      user: "Michael Chen",
      car: "Tesla Model 3",
      startDate: "Mar 15, 2024",
      endDate: "Mar 18, 2024",
      price: 267,
      status: "pending"
    },
    {
      id: "2",
      user: "Emily Rodriguez",
      car: "BMW X5",
      startDate: "Mar 20, 2024",
      endDate: "Mar 25, 2024",
      price: 625,
      status: "pending"
    }
  ];

  const upcomingBookings = [
    {
      id: "3",
      user: "David Park",
      car: "Tesla Model 3",
      startDate: "Mar 22, 2024",
      endDate: "Mar 24, 2024",
      price: 178,
      status: "confirmed"
    }
  ];

  const recentActivity = [
    {
      id: "1",
      type: "review",
      user: "Sarah Johnson",
      message: "Left a 5-star review for Tesla Model 3",
      time: "2 hours ago"
    },
    {
      id: "2",
      type: "booking",
      user: "Mark Wilson",
      message: "Completed booking for BMW X5",
      time: "5 hours ago"
    },
    {
      id: "3",
      type: "payment",
      user: "System",
      message: "Payment of $625 received",
      time: "1 day ago"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-4xl font-bold mb-2">Owner Dashboard</h1>
          <p className="text-muted-foreground">Manage your cars and bookings</p>
        </div>
        <Link href="/list-car">
          <Button data-testid="button-add-car">
            <Plus className="mr-2 h-4 w-4" />
            Add New Car
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Earnings
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.totalEarnings.toLocaleString()}</div>
            <p className="text-xs text-chart-2">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.thisMonth.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">From {stats.activeBookings} active bookings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Bookings
            </CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalBookings}</div>
            <p className="text-xs text-muted-foreground">{stats.carsListed} cars listed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Average Rating
            </CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgRating}</div>
            <p className="text-xs text-muted-foreground">From 87 reviews</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="requests" className="space-y-6">
        <TabsList>
          <TabsTrigger value="requests" data-testid="tab-requests">
            Booking Requests ({bookingRequests.length})
          </TabsTrigger>
          <TabsTrigger value="upcoming" data-testid="tab-upcoming">
            Upcoming ({upcomingBookings.length})
          </TabsTrigger>
          <TabsTrigger value="activity" data-testid="tab-activity">
            Recent Activity
          </TabsTrigger>
        </TabsList>

        <TabsContent value="requests" className="space-y-4">
          {bookingRequests.length > 0 ? (
            bookingRequests.map((booking) => (
              <Card key={booking.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback>{booking.user.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-lg mb-1">{booking.user}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{booking.car}</p>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            {booking.startDate} - {booking.endDate}
                          </div>
                          <div className="font-semibold">${booking.price}</div>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" data-testid={`button-reject-${booking.id}`}>
                        <X className="mr-2 h-4 w-4" />
                        Decline
                      </Button>
                      <Button size="sm" data-testid={`button-accept-${booking.id}`}>
                        <Check className="mr-2 h-4 w-4" />
                        Accept
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="font-semibold text-lg mb-2">No pending requests</h3>
                <p className="text-muted-foreground">
                  You're all caught up! New booking requests will appear here.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingBookings.map((booking) => (
            <Card key={booking.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback>{booking.user.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-lg mb-1">{booking.user}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{booking.car}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          {booking.startDate} - {booking.endDate}
                        </div>
                        <div className="font-semibold">${booking.price}</div>
                        <Badge variant="secondary" className="bg-chart-2/10 text-chart-2">
                          Confirmed
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" data-testid={`button-view-${booking.id}`}>
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-4 pb-4 border-b last:border-0 last:pb-0">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>{activity.user.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm mb-1">
                        <span className="font-semibold">{activity.user}</span>{" "}
                        {activity.message}
                      </p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
