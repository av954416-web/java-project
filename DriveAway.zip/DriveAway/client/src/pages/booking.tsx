import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema } from "@shared/schema";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { 
  Car, 
  MapPin, 
  Calendar as CalendarIcon,
  CreditCard,
  Shield,
  CheckCircle2,
  Clock
} from "lucide-react";

const bookingFormSchema = insertBookingSchema.extend({
  cardNumber: z.string().min(1, "Card number is required"),
  expiry: z.string().min(1, "Expiry date is required"),
  cvv: z.string().min(3, "CVV is required"),
}).omit({
  userId: true,
  carId: true,
  totalPrice: true,
  status: true,
  paymentStatus: true,
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

export default function Booking() {
  const [, setLocation] = useLocation();
  
  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      startDate: new Date(2024, 2, 15),
      endDate: new Date(2024, 2, 18),
      pickupLocation: "San Francisco, CA",
      dropoffLocation: "San Francisco, CA",
      notes: "",
      cardNumber: "",
      expiry: "",
      cvv: "",
    },
  });

  // Mock car data
  const car = {
    make: "Tesla",
    model: "Model 3",
    year: 2024,
    price: 89,
    image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=400&h=300&fit=crop",
    owner: "Sarah Mitchell"
  };

  const calculateDays = () => {
    const start = form.watch("startDate");
    const end = form.watch("endDate");
    return Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  };

  const calculateTotal = () => {
    const days = calculateDays();
    const subtotal = days * car.price;
    const serviceFee = subtotal * 0.1;
    return {
      days,
      subtotal,
      serviceFee,
      total: subtotal + serviceFee
    };
  };

  const costs = calculateTotal();

  const onSubmit = (data: BookingFormValues) => {
    console.log(data);
    // Handle booking submission - will be connected to backend
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-muted/30 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="font-display text-4xl font-bold mb-8">Complete Your Booking</h1>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Form */}
                <div className="lg:col-span-2 space-y-6">
              {/* Trip Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarIcon className="h-5 w-5" />
                    Trip Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Date</FormLabel>
                          <FormControl>
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              className="rounded-md border"
                              disabled={(date) => date < new Date()}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date</FormLabel>
                          <FormControl>
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              className="rounded-md border"
                              disabled={(date) => date <= form.watch("startDate")}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Location Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Pickup & Dropoff
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="pickupLocation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pickup Location</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter pickup location"
                            data-testid="input-pickup-location"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dropoffLocation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Dropoff Location</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter dropoff location"
                            data-testid="input-dropoff-location"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Special Requests (Optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Any special requests or notes for the owner..."
                            rows={3}
                            data-testid="textarea-notes"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Payment Method
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="cardNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Card Number</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="1234 5678 9012 3456"
                            data-testid="input-card-number"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="expiry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Expiry Date</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="MM/YY"
                              data-testid="input-expiry"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="cvv"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CVV</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="123"
                              data-testid="input-cvv"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="flex items-start gap-2 p-4 bg-muted/50 rounded-lg">
                    <Shield className="h-5 w-5 text-chart-2 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium mb-1">Secure Payment</p>
                      <p className="text-xs text-muted-foreground">
                        Your payment information is encrypted and secure. We never store your card details.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cancellation Policy */}
              <Card>
                <CardHeader>
                  <CardTitle>Cancellation Policy</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-chart-2 mt-0.5" />
                      <div>
                        <p className="font-medium mb-1">Free cancellation</p>
                        <p className="text-muted-foreground">
                          Cancel up to 24 hours before pickup for a full refund
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="h-5 w-5 text-chart-3 mt-0.5" />
                      <div>
                        <p className="font-medium mb-1">Partial refund</p>
                        <p className="text-muted-foreground">
                          50% refund if cancelled within 24 hours of pickup
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary Sidebar */}
            <div className="lg:col-span-1">
              <Card className="sticky top-20">
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Car Info */}
                  <div className="flex gap-3">
                    <img 
                      src={car.image} 
                      alt={`${car.make} ${car.model}`}
                      className="w-20 h-20 rounded-md object-cover"
                    />
                    <div>
                      <h3 className="font-semibold">
                        {car.make} {car.model}
                      </h3>
                      <p className="text-sm text-muted-foreground">{car.year}</p>
                      <p className="text-sm text-muted-foreground">by {car.owner}</p>
                    </div>
                  </div>

                  <Separator />

                  {/* Trip Info */}
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Trip Duration</span>
                      <span className="font-medium">{costs.days} days</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Pickup</span>
                      <span className="font-medium">{form.watch("startDate").toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Dropoff</span>
                      <span className="font-medium">{form.watch("endDate").toLocaleDateString()}</span>
                    </div>
                  </div>

                  <Separator />

                  {/* Price Breakdown */}
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">
                        ${car.price} × {costs.days} days
                      </span>
                      <span className="font-medium">${costs.subtotal}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Service fee (10%)</span>
                      <span className="font-medium">${costs.serviceFee.toFixed(2)}</span>
                    </div>
                  </div>

                  <Separator />

                  {/* Total */}
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span>${costs.total.toFixed(2)}</span>
                  </div>

                  <Button 
                    type="submit"
                    className="w-full" 
                    size="lg"
                    data-testid="button-confirm-booking"
                  >
                    Confirm & Pay
                  </Button>

                  <p className="text-xs text-center text-muted-foreground">
                    By confirming, you agree to our Terms of Service and Privacy Policy
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </Form>
        </div>
      </div>
    </div>
  );
}
