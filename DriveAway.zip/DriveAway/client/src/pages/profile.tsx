import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Star, 
  CheckCircle2, 
  Calendar,
  MapPin,
  Shield,
  Mail,
  Phone,
  Edit,
  Car
} from "lucide-react";

export default function Profile() {
  const [activeTab, setActiveTab] = useState("about");

  // Mock user data
  const user = {
    id: "1",
    name: "Sarah Mitchell",
    email: "sarah.mitchell@example.com",
    phone: "+1 (555) 123-4567",
    avatarUrl: null,
    bio: "Car enthusiast and frequent traveler. I love exploring new places and believe in the sharing economy. As a verified owner, I take pride in maintaining my vehicles in top condition.",
    verificationStatus: "approved" as const,
    role: "owner" as const,
    memberSince: "January 2022",
    location: "San Francisco, CA",
    rating: 4.9,
    totalReviews: 87,
    totalTrips: 143,
    responseRate: "98%",
    carsListed: 2
  };

  const reviews = [
    {
      id: "1",
      reviewer: "Michael Chen",
      rating: 5,
      date: "2 weeks ago",
      comment: "Sarah was an excellent host! The Tesla was in perfect condition and she was very responsive to all my questions.",
      type: "owner"
    },
    {
      id: "2",
      reviewer: "Emily Rodriguez",
      rating: 5,
      date: "1 month ago",
      comment: "Great experience renting from Sarah. The car was clean, well-maintained, and pickup was seamless.",
      type: "owner"
    },
    {
      id: "3",
      reviewer: "David Park",
      rating: 4,
      date: "2 months ago",
      comment: "Very professional and accommodating. Would definitely rent from Sarah again!",
      type: "owner"
    }
  ];

  const cars = [
    {
      id: "1",
      make: "Tesla",
      model: "Model 3",
      year: 2024,
      price: 89,
      rating: 4.9,
      reviews: 127,
      image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=800&h=500&fit=crop",
      status: "Available"
    },
    {
      id: "2",
      make: "BMW",
      model: "X5",
      year: 2023,
      price: 125,
      rating: 4.8,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&h=500&fit=crop",
      status: "Booked"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Profile Info */}
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-32 w-32 mb-4">
                  <AvatarImage src={user.avatarUrl || undefined} />
                  <AvatarFallback className="text-3xl">{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                
                <div className="flex items-center gap-2 mb-2">
                  <h1 className="text-2xl font-bold">{user.name}</h1>
                  {user.verificationStatus === "approved" && (
                    <CheckCircle2 className="h-6 w-6 text-chart-2" />
                  )}
                </div>

                {user.verificationStatus === "approved" ? (
                  <Badge variant="secondary" className="mb-4">
                    <Shield className="mr-1 h-3 w-3" />
                    Verified {user.role === "owner" ? "Owner" : "Renter"}
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="mb-4">
                    Verification Pending
                  </Badge>
                )}

                <Button className="w-full mb-4" data-testid="button-edit-profile">
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Profile
                </Button>

                <Separator className="my-4 w-full" />

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 w-full mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{user.rating}</div>
                    <div className="text-sm text-muted-foreground">Rating</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{user.totalReviews}</div>
                    <div className="text-sm text-muted-foreground">Reviews</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{user.totalTrips}</div>
                    <div className="text-sm text-muted-foreground">Trips</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{user.responseRate}</div>
                    <div className="text-sm text-muted-foreground">Response</div>
                  </div>
                </div>

                <Separator className="my-4 w-full" />

                {/* Contact Info */}
                <div className="space-y-3 w-full text-left">
                  <div className="flex items-center gap-3 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Joined {user.memberSince}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{user.location}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{user.email}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{user.phone}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Tabs */}
        <div className="lg:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="about" data-testid="tab-about">About</TabsTrigger>
              <TabsTrigger value="reviews" data-testid="tab-reviews">Reviews ({user.totalReviews})</TabsTrigger>
              {user.role === "owner" && (
                <TabsTrigger value="cars" data-testid="tab-cars">Cars ({user.carsListed})</TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="about" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>About</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{user.bio}</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="mt-6 space-y-4">
              {reviews.map((review) => (
                <Card key={review.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarFallback>{review.reviewer.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold">{review.reviewer}</h4>
                          <div className="flex items-center gap-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < review.rating
                                    ? "fill-chart-3 text-chart-3"
                                    : "text-muted-foreground/30"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{review.date}</p>
                        <p className="text-sm">{review.comment}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            {user.role === "owner" && (
              <TabsContent value="cars" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {cars.map((car) => (
                    <Card key={car.id} className="overflow-hidden hover-elevate active-elevate-2 transition-all cursor-pointer" data-testid={`card-car-${car.id}`}>
                      <div className="aspect-video relative overflow-hidden">
                        <img 
                          src={car.image} 
                          alt={`${car.make} ${car.model}`}
                          className="w-full h-full object-cover"
                        />
                        <Badge className="absolute top-3 right-3 bg-background/90 backdrop-blur-sm">
                          ${car.price}/day
                        </Badge>
                        <Badge 
                          className={`absolute top-3 left-3 ${
                            car.status === "Available" ? "bg-chart-2" : "bg-muted"
                          }`}
                        >
                          {car.status}
                        </Badge>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-lg mb-1">
                          {car.make} {car.model}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-2">{car.year}</p>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-chart-3 text-chart-3" />
                          <span className="text-sm font-medium">{car.rating}</span>
                          <span className="text-xs text-muted-foreground">({car.reviews})</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            )}
          </Tabs>
        </div>
      </div>
    </div>
  );
}
