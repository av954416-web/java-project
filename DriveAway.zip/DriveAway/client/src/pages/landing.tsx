import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Car, 
  Shield, 
  Clock, 
  Star, 
  CheckCircle2, 
  TrendingUp,
  Search,
  MapPin,
  Calendar
} from "lucide-react";

export default function Landing() {
  const featuredCars = [
    {
      id: "1",
      make: "Tesla",
      model: "Model 3",
      year: 2024,
      price: 89,
      location: "San Francisco, CA",
      rating: 4.9,
      reviews: 127,
      image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=800&h=500&fit=crop",
      features: ["Electric", "Autopilot", "Premium Interior"],
      owner: { name: "Sarah M.", verified: true }
    },
    {
      id: "2",
      make: "BMW",
      model: "X5",
      year: 2023,
      price: 125,
      location: "Los Angeles, CA",
      rating: 4.8,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800&h=500&fit=crop",
      features: ["Luxury", "AWD", "Panoramic Roof"],
      owner: { name: "Michael R.", verified: true }
    },
    {
      id: "3",
      make: "Mercedes",
      model: "C-Class",
      year: 2024,
      price: 95,
      location: "San Diego, CA",
      rating: 5.0,
      reviews: 64,
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&h=500&fit=crop",
      features: ["Premium", "Navigation", "Leather Seats"],
      owner: { name: "Emily J.", verified: true }
    }
  ];

  const trustFeatures = [
    {
      icon: Shield,
      title: "Verified Owners",
      description: "All car owners are verified with ID and background checks for your safety"
    },
    {
      icon: Clock,
      title: "24/7 Support",
      description: "Round-the-clock customer support for any questions or emergencies"
    },
    {
      icon: Star,
      title: "Top-Rated Fleet",
      description: "Only highly-rated vehicles and owners on our marketplace"
    }
  ];

  const howItWorks = [
    {
      step: "1",
      title: "Search & Compare",
      description: "Browse verified vehicles by location, price, and features",
      icon: Search
    },
    {
      step: "2",
      title: "Book Instantly",
      description: "Choose your dates, confirm pickup location, and book securely",
      icon: Calendar
    },
    {
      step: "3",
      title: "Drive Away",
      description: "Meet the owner, inspect the vehicle, and hit the road",
      icon: Car
    }
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1920&h=1080&fit=crop')`
          }}
        />
        
        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6">
            Rent Premium Cars<br />From Trusted Owners
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
            Experience the freedom of driving your dream car. Safe, verified, and affordable.
          </p>
          
          {/* Search Bar */}
          <div className="flex flex-col sm:flex-row gap-3 max-w-3xl mx-auto bg-white/95 backdrop-blur-sm p-2 rounded-lg shadow-xl">
            <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-background rounded-md">
              <MapPin className="h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Where?"
                className="flex-1 bg-transparent outline-none text-foreground"
                data-testid="input-hero-location"
              />
            </div>
            <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-background rounded-md">
              <Calendar className="h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="When?"
                className="flex-1 bg-transparent outline-none text-foreground"
                data-testid="input-hero-dates"
              />
            </div>
            <Link href="/browse">
              <Button size="lg" className="w-full sm:w-auto" data-testid="button-search-cars">
                <Search className="mr-2 h-5 w-5" />
                Search Cars
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Features */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {trustFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="flex flex-col items-center text-center gap-4">
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Cars */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="font-display text-4xl font-bold mb-2">Featured Vehicles</h2>
              <p className="text-muted-foreground">Top-rated cars from verified owners</p>
            </div>
            <Link href="/browse">
              <Button variant="outline" data-testid="button-view-all">
                View All
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCars.map((car) => (
              <Link key={car.id} href={`/cars/${car.id}`}>
                <Card className="overflow-hidden hover-elevate active-elevate-2 transition-all cursor-pointer" data-testid={`card-car-${car.id}`}>
                  <div className="aspect-[16/10] relative overflow-hidden">
                    <img 
                      src={car.image} 
                      alt={`${car.make} ${car.model}`}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-3 right-3 bg-background/90 backdrop-blur-sm">
                      ${car.price}/day
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-lg">{car.make} {car.model}</h3>
                        <p className="text-sm text-muted-foreground">{car.year}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-chart-3 text-chart-3" />
                        <span className="text-sm font-medium">{car.rating}</span>
                        <span className="text-xs text-muted-foreground">({car.reviews})</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                      <MapPin className="h-4 w-4" />
                      {car.location}
                    </div>

                    <div className="flex flex-wrap gap-2 mb-3">
                      {car.features.slice(0, 3).map((feature, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 pt-3 border-t">
                      <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium">
                        {car.owner.name.charAt(0)}
                      </div>
                      <span className="text-sm">{car.owner.name}</span>
                      {car.owner.verified && (
                        <CheckCircle2 className="h-4 w-4 text-chart-2" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg">Get on the road in three simple steps</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {howItWorks.map((step) => {
              const Icon = step.icon;
              return (
                <div key={step.step} className="relative">
                  <div className="flex flex-col items-center text-center gap-4">
                    <div className="relative">
                      <div className="h-20 w-20 rounded-full bg-primary flex items-center justify-center">
                        <Icon className="h-10 w-10 text-primary-foreground" />
                      </div>
                      <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-chart-5 text-white flex items-center justify-center font-bold">
                        {step.step}
                      </div>
                    </div>
                    <h3 className="text-2xl font-semibold">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <TrendingUp className="h-16 w-16 mx-auto mb-6" />
          <h2 className="font-display text-4xl font-bold mb-4">
            Got a car? Turn it into income
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            List your vehicle on DriveHub and start earning. It's free to join, and you set your own prices.
          </p>
          <Link href="/list-car">
            <Button size="lg" variant="secondary" data-testid="button-become-owner">
              <Car className="mr-2 h-5 w-5" />
              List Your Car
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
