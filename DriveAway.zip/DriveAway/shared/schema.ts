import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum("user_role", ["renter", "owner", "admin"]);
export const verificationStatusEnum = pgEnum("verification_status", ["pending", "approved", "rejected"]);
export const bookingStatusEnum = pgEnum("booking_status", ["pending", "confirmed", "active", "completed", "cancelled"]);
export const carTypeEnum = pgEnum("car_type", ["sedan", "suv", "truck", "van", "sports", "luxury", "electric"]);
export const transmissionEnum = pgEnum("transmission", ["automatic", "manual"]);

// Users Table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull().default("renter"),
  name: text("name").notNull(),
  phone: text("phone"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  avatarUrl: text("avatar_url"),
  verificationStatus: verificationStatusEnum("verification_status").notNull().default("pending"),
  idDocumentUrl: text("id_document_url"),
  selfieUrl: text("selfie_url"),
  memberSince: timestamp("member_since").notNull().defaultNow(),
  bio: text("bio"),
});

// Cars Table
export const cars = pgTable("cars", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ownerId: varchar("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  carType: carTypeEnum("car_type").notNull(),
  transmission: transmissionEnum("transmission").notNull(),
  seats: integer("seats").notNull(),
  pricePerDay: decimal("price_per_day", { precision: 10, scale: 2 }).notNull(),
  location: text("location").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  description: text("description"),
  features: text("features").array(), // AC, GPS, Bluetooth, etc.
  images: text("images").array(),
  isAvailable: boolean("is_available").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Bookings Table
export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  carId: varchar("car_id").notNull().references(() => cars.id, { onDelete: "cascade" }),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  pickupLocation: text("pickup_location").notNull(),
  dropoffLocation: text("dropoff_location").notNull(),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  status: bookingStatusEnum("status").notNull().default("pending"),
  paymentStatus: text("payment_status").notNull().default("pending"), // pending, completed, refunded
  createdAt: timestamp("created_at").notNull().defaultNow(),
  preRentalPhotos: text("pre_rental_photos").array(),
  postRentalPhotos: text("post_rental_photos").array(),
  odometerStart: integer("odometer_start"),
  odometerEnd: integer("odometer_end"),
  notes: text("notes"),
});

// Reviews Table (bidirectional: users can review cars/owners, owners can review users)
export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  bookingId: varchar("booking_id").notNull().references(() => bookings.id, { onDelete: "cascade" }),
  reviewerId: varchar("reviewer_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  reviewedId: varchar("reviewed_id").notNull().references(() => users.id, { onDelete: "cascade" }), // can be user or owner
  carId: varchar("car_id").references(() => cars.id, { onDelete: "set null" }), // if reviewing a car
  rating: integer("rating").notNull(), // 1-5
  comment: text("comment"),
  reviewType: text("review_type").notNull(), // "car", "renter", "owner"
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  ownedCars: many(cars),
  bookings: many(bookings),
  reviewsGiven: many(reviews, { relationName: "reviewsGiven" }),
  reviewsReceived: many(reviews, { relationName: "reviewsReceived" }),
}));

export const carsRelations = relations(cars, ({ one, many }) => ({
  owner: one(users, {
    fields: [cars.ownerId],
    references: [users.id],
  }),
  bookings: many(bookings),
  reviews: many(reviews),
}));

export const bookingsRelations = relations(bookings, ({ one, many }) => ({
  user: one(users, {
    fields: [bookings.userId],
    references: [users.id],
  }),
  car: one(cars, {
    fields: [bookings.carId],
    references: [cars.id],
  }),
  reviews: many(reviews),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  booking: one(bookings, {
    fields: [reviews.bookingId],
    references: [bookings.id],
  }),
  reviewer: one(users, {
    fields: [reviews.reviewerId],
    references: [users.id],
    relationName: "reviewsGiven",
  }),
  reviewed: one(users, {
    fields: [reviews.reviewedId],
    references: [users.id],
    relationName: "reviewsReceived",
  }),
  car: one(cars, {
    fields: [reviews.carId],
    references: [cars.id],
  }),
}));

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  memberSince: true,
}).extend({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(2),
});

export const insertCarSchema = createInsertSchema(cars).omit({
  id: true,
  createdAt: true,
}).extend({
  pricePerDay: z.string().or(z.number()),
  year: z.number().min(1900).max(new Date().getFullYear() + 1),
  seats: z.number().min(1).max(12),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
}).extend({
  totalPrice: z.string().or(z.number()),
  startDate: z.string().or(z.date()),
  endDate: z.string().or(z.date()),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
}).extend({
  rating: z.number().min(1).max(5),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCar = z.infer<typeof insertCarSchema>;
export type Car = typeof cars.$inferSelect;

export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

// Extended types with relations
export type CarWithOwner = Car & { owner: User };
export type BookingWithDetails = Booking & { car: Car; user: User };
export type ReviewWithDetails = Review & { reviewer: User; reviewed: User; car?: Car };
